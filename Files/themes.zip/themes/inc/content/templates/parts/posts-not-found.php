<p class="qodef-m-posts-not-found qodef-grid-item"><?php esc_html_e( 'No posts were found for provided query parameters.', 'qi' ); ?></p>
