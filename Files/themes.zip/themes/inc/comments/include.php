<?php

include_once QI_INC_ROOT_DIR . '/comments/helper.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
